export const candidateStatus = {
    1: "Referred",
    2: "Interviewed",
    3: "Hired",
    4: "Joined",
    5: "Progress",
    6: "Reward"
  }